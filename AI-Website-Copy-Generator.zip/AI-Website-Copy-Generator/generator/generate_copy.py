import json

# Load prompt template
with open("../prompts/website_prompt.txt", "r") as file:
    prompt_template = file.read()

# Load business data
with open("../data/business_input.json", "r") as file:
    business_data = json.load(file)

# Replace placeholders
prompt = prompt_template.format(
    business_name=business_data["business_name"],
    business_type=business_data["business_type"],
    location=business_data["location"],
    audience=business_data["audience"],
    services=", ".join(business_data["services"]),
    usp=business_data["usp"],
    tone=business_data["tone"]
)

# Save prompt output
with open("../outputs/website_copy.txt", "w") as file:
    file.write(prompt)

print("Website copy prompt generated successfully!")