# AI Website Copy Generator for Local Businesses

## Project Overview
This project demonstrates a prompt engineering system that generates
conversion-focused website copy for local businesses using AI.

The system collects business information and produces ready-to-use
website content including homepage copy, services descriptions, and
call-to-action sections.

## Business Example
Brew Haven Cafe – Pune, India

A local coffee shop targeting students, freelancers, and coffee lovers.

## Tools Used
Python
Prompt Engineering
AI tools like ChatGPT / Gemini / Claude

## Project Structure

ai-website-copy-generator

prompts/
website_prompt.txt

data/
business_input.json

generator/
generate_copy.py

outputs/
website_copy.txt

README.md

## How To Run

1 Install Python

2 Clone the repository

3 Run the generator script

python generator/generate_copy.py

4 Check generated output inside

outputs/website_copy.txt

## Use Case

This system can generate website copy for many businesses including:

- cafes
- salons
- clinics
- coaching institutes
- agencies